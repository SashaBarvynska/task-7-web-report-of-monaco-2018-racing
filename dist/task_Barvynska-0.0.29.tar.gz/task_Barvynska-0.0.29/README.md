# Task 6 - Report of Monaco 2018 Racing

